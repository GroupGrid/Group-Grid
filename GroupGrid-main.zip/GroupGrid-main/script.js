// JavaScript to handle the "Get Started" button
document.getElementById('signupBtn').addEventListener('click', function() {
    window.location.href = "sign_up.html"; // Redirect to signup page
});
document.getElementById('logBTn').addEventListener('click', function() {
    window.location.href = "login.html"; // Redirect to signup page
});
